@artifact.package@import org.zkoss.zk.grails.composer.*

import org.zkoss.zk.ui.select.annotation.Wire
import org.zkoss.zk.ui.select.annotation.Listen

class @artifact.name@ extends GrailsComposer {

    def afterCompose = { window ->
        // initialize components here
    }
}
