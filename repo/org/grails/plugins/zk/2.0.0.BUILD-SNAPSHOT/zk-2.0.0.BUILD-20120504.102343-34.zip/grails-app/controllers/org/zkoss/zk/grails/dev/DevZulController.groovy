package org.zkoss.zk.grails.dev

class DevZulController {

	def devHolder

	//
	// index?r=index.zul
	def index() {
		if(devHolder.check('/zul' + params['r'])) {
			response.setDateHeader('Last-Modified', new Date().time)
			response.sendError(200)
		} else {
			response.sendError(200)
		}
	}

}