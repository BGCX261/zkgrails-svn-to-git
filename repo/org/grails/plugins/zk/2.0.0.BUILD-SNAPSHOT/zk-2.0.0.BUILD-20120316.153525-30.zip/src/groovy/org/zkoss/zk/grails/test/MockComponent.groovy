package org.zkoss.zk.grails.test

class MockComponent {
	
}